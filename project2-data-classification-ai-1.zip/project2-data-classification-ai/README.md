# Data Classification Using AI

## Project 2 - Internship

### Objective
Build a basic classification model using a small dataset. This project demonstrates how to load and understand data, split it into training and testing sets, train a classification algorithm, and evaluate the model.

### Dataset
The project uses a small version of the **Iris flower dataset**. It contains measurements of:
- Sepal length
- Sepal width
- Petal length
- Petal width

The target classes are:
- Setosa
- Versicolor
- Virginica

### Key Requirements Covered
- Load and understand a dataset
- Split data into training and testing sets
- Apply a simple classification algorithm
- Train a machine learning model
- Evaluate model accuracy

### Algorithm Used
**Decision Tree Classifier**

A Decision Tree is a simple supervised learning algorithm that makes decisions using feature-based rules.

### Technologies Used
- Python 3
- Pandas
- Scikit-learn

### Project Structure
```text
project2-data-classification-ai/
├── classifier.py
├── iris.csv
├── README.md
└── requirements.txt
```

### How to Run

1. Install Python 3.
2. Open a terminal in this project folder.
3. Install the required libraries:

```bash
pip install -r requirements.txt
```

4. Run the program:

```bash
python classifier.py
```

### Expected Output
The program displays:
- First five rows of the dataset
- Dataset size
- Class distribution
- Number of training and testing samples
- Model accuracy
- Classification report
- Prediction for a sample flower

### Key Skills Demonstrated
- Data handling
- Supervised learning
- Training and testing data
- Classification
- Model training
- Model evaluation
